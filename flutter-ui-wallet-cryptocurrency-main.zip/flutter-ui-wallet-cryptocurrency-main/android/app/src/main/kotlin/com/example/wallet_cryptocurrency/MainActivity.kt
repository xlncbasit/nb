package com.example.wallet_cryptocurrency

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
