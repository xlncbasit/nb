# Flutter UI Wallet Cryptocurrency

## References 
[wallet cryptocurrency mobile app](https://www.freepik.com/free-psd/template-wallet-cryptocurrency-mobile-app_12385833.htm)

![Wallet_Cryptocurrency_Mobile_App](https://user-images.githubusercontent.com/37796466/109503400-cb708c80-7acc-11eb-8d47-37acd362204c.jpg)

## Flutter

![Wallet_Cryptocurrency_Mobile_App - flutter](https://user-images.githubusercontent.com/37796466/110117690-d0468080-7deb-11eb-9965-fd1722bd78b2.jpg)
